<div class="wrapper row4">
  <footer id="footer" class="hoc clear"> 
    <!-- ################################################################################################ -->
     <section id="services">
      <div class="sectiontitle">
        <h5 class="heading">Vision & Mision</h5>
      </div>
      </ul>
    </section>
   <section id="services">
      <div class="sectiontitle">
        <h5 class="heading">Vision</h5>
         <p>Membuat kemajuan pada dunia perikanan dengan teknologi dan menerapkan teknologi dengan segala kreatifitas dan tanggungjawab untuk meningkatkan kualitas hidup masyarakat perikanan Indonesia.</p>
      </div>
      </ul>
    </section>
    <section id="services">
      <div class="sectiontitle">
        <h5 class="heading">Mission</h5>
         <p>Berkreativitas dan Berinovasi  untuk mengenali teknologi lebih kompleks dengan  terus mengasah kreatifitas, imajinasi dan mengembangkan logika berpikir demi kehidupan yang lebih baik.
         </p>
      </div>
      </ul>
    </section>
      </ul>
    </div>
    <!-- ################################################################################################ -->
  </footer>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row5">
  <div id="copyright" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <p class="fl_left">Copyright &copy; 2020 - All Rights Reserved - <a href="http://gainztech.my.id/">GainzTech</a></p>
    <!-- ################################################################################################ -->
  </div>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<a id="backtotop" href="#top"><i class="fas fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="layout/scripts/jquery.min.js"></script>
<script src="layout/scripts/jquery.backtotop.js"></script>
<script src="layout/scripts/jquery.mobilemenu.js"></script>
</body>
</html>